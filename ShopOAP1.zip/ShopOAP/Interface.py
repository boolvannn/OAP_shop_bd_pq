import sqlite3
from PyQt5 import QtWidgets, uic

DB_PATH = "shop2(1).db"

class AddForm(QtWidgets.QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        uic.loadUi("interface2.ui", self)
        self.parent = parent
        self.pushButton.clicked.connect(self.add_entry)
        self.load_comboboxes()

    def load_comboboxes(self):
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()

        cursor.execute("SELECT id_shop, name_shop FROM shop")
        self.shops = cursor.fetchall()
        self.comboBox.clear()
        for id_, name in self.shops:
            self.comboBox.addItem(name, id_)

        cursor.execute("SELECT id_product, name_product FROM product")
        self.products = cursor.fetchall()
        self.comboBox_2.clear()
        for id_, name in self.products:
            self.comboBox_2.addItem(name, id_)

        conn.close()

    def add_entry(self):
        id_shop = self.comboBox.currentData()
        id_product = self.comboBox_2.currentData()
        try:
            price = float(self.lineEdit.text())
            count = int(self.lineEdit_2.text())
            if price < 0 or count < 0:
                QtWidgets.QMessageBox.warning(self, "Ошибка", "Цена и количество не могут быть отрицательными.")
                return
        except ValueError:
            QtWidgets.QMessageBox.warning(self, "Ошибка", "Введите корректные значения для цены и количества.")
            return

        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("INSERT INTO itog (id_product, id_shop, price, count) VALUES (?, ?, ?, ?)",
                       (id_product, id_shop, price, count))
        conn.commit()
        conn.close()

        if self.parent:
            self.parent.load_data()
        self.close()

