import sqlite3


conn = sqlite3.connect("shop2(1).db")
cursor = conn.cursor()
cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
tables = cursor.fetchall()
print("Таблицы в базе:", tables)
conn.close()
