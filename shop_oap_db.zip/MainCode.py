import sys
import sqlite3
from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import QMessageBox

DB_PATH = "shop2(1).db"

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi("interface.ui", self)
        self.load_data()
        self.pushButton.clicked.connect(self.open_add_form)
        self.pushButton_2.clicked.connect(self.save_data)
        self.pushButton_3.clicked.connect(self.delete_selected)
        self.comboBox.currentIndexChanged.connect(self.apply_sort)

    def load_data(self):
        self.tableWidget.setRowCount(0)
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT itog.id_itog, product.name_product, shop.name_shop, itog.price, itog.count
            FROM itog
            JOIN shop ON itog.id_shop = shop.id_shop
            JOIN product ON itog.id_product = product.id_product
        """)
        for row_idx, row_data in enumerate(cursor.fetchall()):
            self.tableWidget.insertRow(row_idx)
            for col_idx, value in enumerate(row_data):
                self.tableWidget.setItem(row_idx, col_idx, QtWidgets.QTableWidgetItem(str(value)))
        conn.close()

    def delete_selected(self):
        selected = self.tableWidget.currentRow()
        if selected < 0:
            return
        id_item = self.tableWidget.item(selected, 0)
        if not id_item:
            return
        id_itog = id_item.text()
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM itog WHERE id_itog=?", (id_itog,))
        conn.commit()
        conn.close()
        self.load_data()

    def save_data(self):
        QMessageBox.information(self, "Сохранено", "Изменения сохранены (если были).")

    def apply_sort(self):
        index = self.comboBox.currentIndex()
        order_by = ""
        if index == 1:
            order_by = "ORDER BY itog.price ASC"
        elif index == 2:
            order_by = "ORDER BY itog.price DESC"

        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        query = f"""
            SELECT itog.id_itog, product.name_product, shop.name_shop, itog.price, itog.count
            FROM itog
            JOIN shop ON itog.id_shop = shop.id_shop
            JOIN product ON itog.id_product = product.id_product
            {order_by}
        """
        cursor.execute(query)
        self.tableWidget.setRowCount(0)
        for row_idx, row_data in enumerate(cursor.fetchall()):
            self.tableWidget.insertRow(row_idx)
            for col_idx, value in enumerate(row_data):
                self.tableWidget.setItem(row_idx, col_idx, QtWidgets.QTableWidgetItem(str(value)))
        conn.close()

    def open_add_form(self):
        from Interface import AddForm
        self.add_form = AddForm(self)
        self.add_form.show()

if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
